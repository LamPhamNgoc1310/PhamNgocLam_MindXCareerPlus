import './NavBar.css'

export default function NavBar () {
    return(
        <header>
            <h4 className='logo'>Anonime</h4>
            <p>Home</p>
            <p>List Anime</p>
            <input type="text" placeholder='Search anime or movie' />
        </header>

    )

}